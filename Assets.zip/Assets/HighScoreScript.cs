using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HighScoreScript : MonoBehaviour
{
    Text highScore;

    private void Start()
    {
        highScore = GetComponent<Text>();
    }

    private void Update()
    {
        highScore.text = "High Score: " + ScoreScript.HighScore;
    }
}