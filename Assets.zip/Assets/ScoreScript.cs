using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreScript : MonoBehaviour
{
    public static int TotalScore = 0;
    public static int HighScore = 0;
    Text score;

    private void Start()
    {
        score = GetComponent<Text>();
    }

    private void Update()
    {
        score.text = "Score: " + TotalScore;

        if (TotalScore > HighScore)
        {
            HighScore = TotalScore;
        }
    }
}